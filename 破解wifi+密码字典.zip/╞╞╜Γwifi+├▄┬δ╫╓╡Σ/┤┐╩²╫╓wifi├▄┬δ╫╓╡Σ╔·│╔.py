import itertools as its


def get_WifiPsdDic(len=8):
    words_num = "1234567890"
    words_letter = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    r = its.product(words_num, repeat=len)
    dic = open("dictionary.txt", "w")
    for i in r:
        dic.write("".join(i))
        dic.write("".join("\n"))
    dic.close()


if __name__ == '__main__':
    get_WifiPsdDic(8)
    pass